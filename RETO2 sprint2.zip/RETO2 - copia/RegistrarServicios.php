<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de servicios</title>

    <link rel="stylesheet" href="/css/registrarServicios.css">
</head>

<body>
<style>
        body {
            background: url(../imagenes/fondoRegistroViajejpg.jpg);
        }
        .form-container {
            background-color: white;
            padding: 80px;
            width: 400px;
            border-radius: 8px;
            display: grid;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-weight: bold;
            box-shadow: 5px 5px 40px 1px black;
        }
        .form-container h1 {
            text-align: center; 
            font-size: 19px;
        }
        .form-container button {
            
        }

    </style>
    
    <form class="form-container">
        <div class="logo">
        </div>
        <label for="tipoviaje">Tipo de viaje:</label>
        <select id="viajes" name="viajes" required>
            <option value="">--Elige--</option>
            <option value="Novios">Novios</option>
            <option value="Senior">Senior</option>
            <option value="Grandes viajes (destinos exoticos)">Grandes viajes (destinos exoticos)</option>
            <option value="Combinado (vuelo+hotel)">Combinado (vuelo+hotel)</option>
            <option value="Escapadas">Escapadas</option>
            <option value="Familias con niños menores">Familias con niños menores</option>
        </select>

        <p>¿Que servicio quieres registrar?</p>
        <div class="elegir-servicio">
            <input type="radio" name="ocultar" id ="vuelo" value="vuelo" onclick="mostrarFormulario('vuelo')">
            <label><b>Vuelo</b></label>
            <input type="radio" name="ocultar" id="hotel" value="hotel" onclick="mostrarFormulario('hotel')">
            <label><b>Alojamiento</b></label>
            <input type="radio" name="ocultar" id=value="otros" onclick="mostrarFormulario('otros')">
            <label><b>Otros</b></label>
        </div>

        <!-- Sección Vuelo -->
        <div id="vuelo-section" class="ocultar">
            <p>¿Que tipo de vuelo es?</p>
            <div class="IdaVuelta">
                <input type="radio" name="tipoVuelo" id="ida" value="ida" onclick="mostrarFormularioVuelo('ida')">
                <label><b>Ida</b></label>
                <input type="radio" name="tipoVuelo" id="ida-vuelta" value="ida-vuelta" onclick="mostrarFormularioVuelo('ida-vuelta')">
                <label><b>Ida / Vuelta</b></label>
            </div>

            <label for="aeropuerto-procedencia">Aeropuerto de Origen:</label>
            <select id="aeropuerto-procedencia" name="aeropuerto-procedencia" required>
                <option value="">--Elige--</option>
                <option value="ALC">Alicante</option>
                <option value="OVD">Asturias</option>
                <option value="BCN">Barcelona</option>
                <option value="ODB">Córdoba</option>
                <option value="GRO">Gerona</option>
                <option value="GRX">Granada</option>
                <option value="IBZ">Ibiza</option>
                <option value="LCG">La Coruña LCG</option>
                <option value="ACE">Lanzarote</option>
                <option value="MAD">Madrid</option>
                <option value="MAH">MAHON</option>
                <option value="MJV">Murcia</option>
                <option value="PNA">Pamplona</option>
                <option value="SLM">Salamanca</option>
                <option value="SPC">Santa Cruz de la Palma</option>
                <option value="SCQ">Santiago de Compostela</option>
                <option value="VLC">Valencia</option>
                <option value="VGO">Vigo</option>
                <option value="ZAZ">Zaragoza</option>
                <option value="BJZ">Badajoz</option>
                <option value="BIO">Bilbao</option>
                <option value="VIT">VITORIA</option>
                <option value="TFN">Tenerife Norte</option>
                <option value="TFS">Tenerife Sur</option>
                <option value="SDR">SANTANDER</option>
                <option value="EAS">SAN SEBASTIAN</option>
                <option value="REU">REUS</option>
                <option value="PMI">PALMA DE MALLORCA</option>
                <option value="AGP">MALAGA</option>
                <option value="XRY">JEREZ DE LA FRONTERA</option>
                <option value="LPA">GRAN CANARIA</option>
                <option value="FUE">FUERTEVENTURA</option>
                <option value="VDE">HIERRO</option>
                <option value="GMZ">LA GOMERA</option>
                <option value="YMQ">Montreal, Québec</option>
                <option value="YOW">CANADA Ottawa, Ontario YOW</option>
                <option value="YTO">CANADA Toronto, Ontario YTO</option>
                <option value="YVR">CANADA VANCOUVER</option>
                <option value="BOS">Boston</option>
                <option value="HOU">Houston</option>
                <option value="MIA">Miami</option>
                <option value="LAX">LOS ANGELES</option>
                <option value="JFK">Nueva York</option>
                <option value="DTT">DETROIT</option>
                <option value="PHL">Philadelphia PHL</option>
                <option value="SFO">SAN FRANCISCO</option>
                <option value="SEA">Seattle</option>
                <option value="WAS">WASHINGTON</option>
                <option value="SDQ">REPÚBLICA DOMINICANA (Santo Domingo)</option>
                <option value="KIN">JAMAICA (Kingston)</option>
                <option value="BUE">Buenos Aires</option>
                <option value="RIO">BRASIL (Rio de Janeiro)</option>
                <option value="SAO">BRASIL (Sao Paulo)</option>
                <option value="BOG">COLOMBIA Bogotá</option>
                <option value="LIM">PERU (Lima)</option>
                <option value="CCS">VENEZUELA (Caracas)</option>
                <option value="VIE">AUSTRIA (Viena)</option>
                <option value="PRG">REPÚBLICA CHECA (Praga)</option>
                <option value="HEL">FINLANDIA (Helsinki)</option>
                <option value="LYS">FRANCIA (Lyon)</option>
                <option value="CDG">FRANCIA, París (aeropuerto Charles de Gaulle)</option>
                <option value="LBG">FRANCIA, Le Bourget</option>
                <option value="ORY">FRANCIA (Orly)</option>
                <option value="MRS">FRANCIA (Marsella)</option>
                <option value="BER">ALEMANIA (Berlín)</option>
                <option value="DUS">ALEMANIA (Dusseldorf)</option>
                <option value="FRA">ALEMANIA (Frankfurt)</option>
                <option value="MUC">ALEMANIA (Munich)</option>
                <option value="HAM">ALEMANIA (Hamburgo)</option>
                <option value="ATH">GRECIA (Atenas)</option>
                <option value="DUB">IRLANDA (Dublin)</option>
                <option value="MIL">ITALIA (Milán)</option>
                <option value="MEX">México D.F.</option>
                <option value="ACA">MÉXICO (Acapulco)</option>
                <option value="BSB">BRASIL (Brasilia)</option>
                <option value="STR">ALEMANIA (Stuttgart)</option>
                <option value="CPH">DINAMARCA</option>
                <option value="BRU">BÉLGICA (Bruselas)</option>
                <option value="AMS">HOLANDA (Amsterdam)</option>
                <option value="OSL">NORUEGA (Oslo)</option>
                <option value="WAW">POLONIA (Varsovia) WAW</option>
                <option value="LIS">PORTUGAL (Lisboa)</option>
                <option value="STO">SUECIA (Estocolmo)</option>
                <option value="MOW">RUSIA (Moscú) MOW</option>
                <option value="GVA">SUIZA (Ginebra)</option>
                <option value="ZRH">SUIZA (Zurich)</option>
                <option value="IST">TURQUÍA (Estambul)</option>
                <option value="LGH">LONDRES (Gatwick)</option>
                <option value="LHR">LONDRES (Heathrow)</option>
                <option value="STN">LONDRES (Stansted)</option>
                <option value="CAI">EGIPTO (El Cairo)</option>
                <option value="NBO">KENIA (Nairobi)</option>
                <option value="CAS">MARRUECOS (Casablanca)</option>
                <option value="RAK">MARRUECOS (Marrakech)</option>
                <option value="TUN">TÚNEZ</option>
                <option value="AMM">JORDANIA (Ammán) AMM</option>
                <option value="BKK">TAILANDIA (Bangkok)</option>
                <option value="MEL">AUSTRALIA (Melbourne)</option>
                <option value="SYD">AUSTRALIA (Sydney)</option>
                
                
            </select>


            <label for="aeropuerto-destino">Aeropuerto de Destino</label>
            <select id="aeropuerto-destino" name="aeropuerto-destino" required>
                <option value="">--Elige--</option>
                <option value="ALC">Alicante</option>
                <option value="OVD">Asturias</option>
                <option value="BCN">Barcelona</option>
                <option value="ODB">Córdoba</option>
                <option value="GRO">Gerona</option>
                <option value="GRX">Granada</option>
                <option value="IBZ">Ibiza</option>
                <option value="LCG">La Coruña LCG</option>
                <option value="ACE">Lanzarote</option>
                <option value="MAD">Madrid</option>
                <option value="MAH">MAHON</option>
                <option value="MJV">Murcia</option>
                <option value="PNA">Pamplona</option>
                <option value="SLM">Salamanca</option>
                <option value="SPC">Santa Cruz de la Palma</option>
                <option value="SCQ">Santiago de Compostela</option>
                <option value="VLC">Valencia</option>
                <option value="VGO">Vigo</option>
                <option value="ZAZ">Zaragoza</option>
                <option value="BJZ">Badajoz</option>
                <option value="BIO">Bilbao</option>
                <option value="VIT">VITORIA</option>
                <option value="TFN">Tenerife Norte</option>
                <option value="TFS">Tenerife Sur</option>
                <option value="SDR">SANTANDER</option>
                <option value="EAS">SAN SEBASTIAN</option>
                <option value="REU">REUS</option>
                <option value="PMI">PALMA DE MALLORCA</option>
                <option value="AGP">MALAGA</option>
                <option value="XRY">JEREZ DE LA FRONTERA</option>
                <option value="LPA">GRAN CANARIA</option>
                <option value="FUE">FUERTEVENTURA</option>
                <option value="VDE">HIERRO</option>
                <option value="GMZ">LA GOMERA</option>
                <option value="YMQ">Montreal, Québec</option>
                <option value="YOW">CANADA Ottawa, Ontario YOW</option>
                <option value="YTO">CANADA Toronto, Ontario YTO</option>
                <option value="YVR">CANADA VANCOUVER</option>
                <option value="BOS">Boston</option>
                <option value="HOU">Houston</option>
                <option value="MIA">Miami</option>
                <option value="LAX">LOS ANGELES</option>
                <option value="JFK">Nueva York</option>
                <option value="DTT">DETROIT</option>
                <option value="PHL">Philadelphia PHL</option>
                <option value="SFO">SAN FRANCISCO</option>
                <option value="SEA">Seattle</option>
                <option value="WAS">WASHINGTON</option>
                <option value="SDQ">REPÚBLICA DOMINICANA (Santo Domingo)</option>
                <option value="KIN">JAMAICA (Kingston)</option>
                <option value="BUE">Buenos Aires</option>
                <option value="RIO">BRASIL (Rio de Janeiro)</option>
                <option value="SAO">BRASIL (Sao Paulo)</option>
                <option value="BOG">COLOMBIA Bogotá</option>
                <option value="LIM">PERU (Lima)</option>
                <option value="CCS">VENEZUELA (Caracas)</option>
                <option value="VIE">AUSTRIA (Viena)</option>
                <option value="PRG">REPÚBLICA CHECA (Praga)</option>
                <option value="HEL">FINLANDIA (Helsinki)</option>
                <option value="LYS">FRANCIA (Lyon)</option>
                <option value="CDG">FRANCIA, París (aeropuerto Charles de Gaulle)</option>
                <option value="LBG">FRANCIA, Le Bourget</option>
                <option value="ORY">FRANCIA (Orly)</option>
                <option value="MRS">FRANCIA (Marsella)</option>
                <option value="BER">ALEMANIA (Berlín)</option>
                <option value="DUS">ALEMANIA (Dusseldorf)</option>
                <option value="FRA">ALEMANIA (Frankfurt)</option>
                <option value="MUC">ALEMANIA (Munich)</option>
                <option value="HAM">ALEMANIA (Hamburgo)</option>
                <option value="ATH">GRECIA (Atenas)</option>
                <option value="DUB">IRLANDA (Dublin)</option>
                <option value="MIL">ITALIA (Milán)</option>
                <option value="MEX">México D.F.</option>
                <option value="ACA">MÉXICO (Acapulco)</option>
                <option value="BSB">BRASIL (Brasilia)</option>
                <option value="STR">ALEMANIA (Stuttgart)</option>
                <option value="CPH">DINAMARCA</option>
                <option value="BRU">BÉLGICA (Bruselas)</option>
                <option value="AMS">HOLANDA (Amsterdam)</option>
                <option value="OSL">NORUEGA (Oslo)</option>
                <option value="WAW">POLONIA (Varsovia) WAW</option>
                <option value="LIS">PORTUGAL (Lisboa)</option>
                <option value="STO">SUECIA (Estocolmo)</option>
                <option value="MOW">RUSIA (Moscú) MOW</option>
                <option value="GVA">SUIZA (Ginebra)</option>
                <option value="ZRH">SUIZA (Zurich)</option>
                <option value="IST">TURQUÍA (Estambul)</option>
                <option value="LGH">LONDRES (Gatwick)</option>
                <option value="LHR">LONDRES (Heathrow)</option>
                <option value="STN">LONDRES (Stansted)</option>
                <option value="CAI">EGIPTO (El Cairo)</option>
                <option value="NBO">KENIA (Nairobi)</option>
                <option value="CAS">MARRUECOS (Casablanca)</option>
                <option value="RAK">MARRUECOS (Marrakech)</option>
                <option value="TUN">TÚNEZ</option>
                <option value="AMM">JORDANIA (Ammán) AMM</option>
                <option value="BKK">TAILANDIA (Bangkok)</option>
                <option value="MEL">AUSTRALIA (Melbourne)</option>
                <option value="SYD">AUSTRALIA (Sydney)</option>
                
                
            </select>

            <label for="codigo-vuelo">Código del Vuelo:</label>
            <input type="text" id="codigo-vuelo">

            <label for="aerolinea">Aerolínea:</label>
            <select id="aerolinea" name="aerolinea" required>
                <option value="">--Elige--</option>
                <option value="Aerolinea Vueling SA">Aerolinea Vueling SA</option>
                <option value="RYNAIR">RYNAIR</option>
                <option value="World2Fly">World2Fly</option>
                <option value="Air France">Air France</option>
                <option value="KLM">KLM</option>
                <option value="KLM Cityhopper">KLM Cityhopper</option>
                <option value="TAP Portugal">TAP Portugal</option>
                <option value="World 2 Fly Portugal, S.A.">World 2 Fly Portugal, S.A.</option>
                <option value="Finnair">Finnair</option>
                <option value="Brussels Airlines">Brussels Airlines</option>
                <option value="Condor Flugdienst GmbH">Condor Flugdienst GmbH</option>
                <option value="Lufthansa">Lufthansa</option>
                <option value="Lufthansa CityLine GmbH">Lufthansa CityLine GmbH</option>
                <option value="TUIfly Gmbh">TUIfly Gmbh</option>
                <option value="TUIfly Nordic AB">TUIfly Nordic AB</option>
                <option value="Croatia Airlines d.d.">Croatia Airlines d.d.</option>
                <option value="Air Nostrum, Lineas aereas del Mediterraneo SA">Air Nostrum, Lineas aereas del Mediterraneo SA</option>
                <option value="SATA (Air Acores)">SATA (Air Acores)</option>
                <option value="SATA Internacional - Azores Airlines, S.A.">SATA Internacional - Azores Airlines, S.A.</option>
                <option value="Air Europa Lineas Aereas, S.A.">Air Europa Lineas Aereas, S.A.</option>
                <option value="British Airways PLC">British Airways PLC</option>
                <option value="BA Euroflyer Limited dba British Airways">BA Euroflyer Limited dba British Airways</option>
                <option value="Virgin Atlantic Airways Ltd">Virgin Atlantic Airways Ltd</option>
                <option value="Norse Atlantic Airways AS">Norse Atlantic Airways AS</option>
                <option value="Challenge Airlines (BE) S.A.">Challenge Airlines (BE) S.A.</option>
                <option value="EASYJET UK LIMITED">EASYJET UK LIMITED</option>
                <option value="Easyjet Switzerland S.A">Easyjet Switzerland S.A</option>
                <option value="Edelweiss Air AG">Edelweiss Air AG</option>
                <option value="Air Greenland">Air Greenland</option>
                <option value="SWISS International Air Lines Ltd">SWISS International Air Lines Ltd</option>
                <option value="Turkish Airlines Inc">Turkish Airlines Inc</option>
                <option value="Pegasus Airlines">Pegasus Airlines</option>
                <option value="Malta Air Travel Ltd dba Malta MedAir">Malta Air Travel Ltd dba Malta MedAir</option>
                <option value="Alitalia">Alitalia</option>
                <option value="American Airlines">American Airlines</option>
                <option value="BSA - Aerolinhas Brasileiras S.A dba LATAM Cargo BR">BSA - Aerolinhas Brasileiras S.A dba LATAM Cargo BR</option>
                <option value="Tam Linhas Aereas SA dba Latam Airlines Brasil">Tam Linhas Aereas SA dba Latam Airlines Brasil</option>
                <option value="Delta Air Lines Inc">Delta Air Lines Inc</option>
                <option value="United Airlines Inc">United Airlines Inc</option>
                <option value="China United Airlines">China United Airlines</option>
                <option value="AVIANCA-Ecuador dba AVIANCA">AVIANCA-Ecuador dba AVIANCA</option>
                <option value="Aerovias del Continente Americano S.A. AVIANCA">Aerovias del Continente Americano S.A. AVIANCA</option>
                <option value="Egyptair">Egyptair</option>
                <option value="Aerovias de Mexico SA de CV dba AeroMexico">Aerovias de Mexico SA de CV dba AeroMexico</option>
                <option value="Aerolineas Argentinas S.A.">Aerolineas Argentinas S.A.</option>
                <option value="Air Transat">Air Transat</option>
                <option value="Alia - The Royal Jordanian Airlines dba Royal Jordanian">Alia - The Royal Jordanian Airlines dba Royal Jordanian</option>
                <option value="Qatar Airways Group Q.C.S.C dba Qatar Airways">Qatar Airways Group Q.C.S.C dba Qatar Airways</option>
                
            </select>

            <label for="precio">Precio (€):</label>
            <input type="number" id="precio" required>

            <label for="fecha-salida">Fecha de salida:</label>
            <input type="date" id="fecha-salida">

            <label for="hora-salida">Hora de salida</label>
            <input type="time" id="hora-salida">

            <label for="duracion-viaje" id="">Duración del viaje (en horas):</label>
            <input type="number" id="duracion-viaje">

            <!-- Sección Ida y Vuelta -->
            <div id="vuelta-section" class="ocultar">
                <p>Vuelo (vuelta)</p>
                <label for="fecha-vuelta">Fecha de Vuelta:</label>
                <input type="date" id="fecha-vuelta">

                <label for="hora-vuelta">Hora de Vuelta:</label>
                <input type="time" id="hora-vuelta">

                <label for="viaje-duracion-vuelta">Duración del Vuelo de Vuelta (en horas):</label>
                <input type="number" id="viaje-duracion-vuelta">

                <label for="vuelo-codigo-vuelta">Código del Vuelo de Vuelta:</label>
                <input type="text" id="vuelo-codigo-vuelta">

                <label for="aerolinea-vuelta">Aerolínea de Vuelta:</label>
                <select id="aerolinea-vuelta" name="aerolinea-vuelta" required>
                    <option value="">--Elige--</option>
                    <option value="Aerolinea Vueling SA"></option>
                    <option value="RYNAIR"></option>
                    <option value="World2Fly"></option>
                    <option value="Air France"></option>
                    <option value="KLM"></option>
                    <option value="KLM Cityhopper"></option>
                    <option value="TAP Portugal"></option>
                    <option value="World 2 Fly Portugal, S.A."></option>
                    <option value="Finnair"></option>
                    <option value="Brussels Airlines"></option>
                    <option value="Condor Flugdienst GmbH"></option>
                    <option value="Lufthansa"></option>
                    <option value="Lufthansa CityLine GmbH"></option>
                    <option value="TUIfly Gmbh"></option>
                    <option value="TUIfly Nordic AB"></option>
                    <option value="Croatia Airlines d.d."></option>
                    <option value="Air Nostrum, Lineas aereas del Mediterra neo SA"></option>
                    <option value="SATA (Air Acores)"></option>
                    <option value="SATA Internacional - Azores Airlines, S.A."></option>
                    <option value="Air Europa Lineas Aereas, S.A."></option>
                    <option value="British Airways PLC"></option>
                    <option value="BA Euroflyer Limited dba British Airways"></option>
                    <option value="Virgin Atlantic Airways Ltd"></option>
                    <option value="Norse Atlantic Airways AS"></option>
                    <option value="Challenge Airlines (BE) S.A."></option>
                    <option value="Virgin Atlantic Airways Ltd"></option>
                    <option value="EASYJET UK LIMITED"></option>
                    <option value="Easyjet Switzerland S.A"></option>
                    <option value="Edelweiss Air AG"></option>
                    <option value="Air Greenland"></option>
                    <option value="SWISS Internation Air Lines Ltd"></option>
                    <option value="Turkish Airlines Inc"></option>
                    <option value="Pegasus Airlines"></option>
                    <option value="Malta Air Travel Ltd dba Malta MedAir"></option>
                    <option value="Alitalia"></option>
                    <option value="American Airlines"></option>
                    <option value="BSA - Aerolinhas Brasileiras S.A dba LATAM Cargo Br"></option>
                    <option value="Tam Linhas Aereas SA dba Latam Airlines Brasil"></option>
                    <option value="Delta Air Lines Inc"></option>
                    <option value="United Airlines Inc"></option>
                    <option value="China United Airlines"></option>
                    <option value="AVIANCA-Ecuador dba AVIANCA"></option>
                    <option value="Aerovias del Continente Americano S.A. AVIANCA"></option>
                    <option value="Egyptair"></option>
                    <option value="Aerovias de Mexico SA de CV dba AeroMexico"></option>
                    <option value="Aerolineas Argentinas S.A."></option>
                    <option value="Air Transat"></option>
                    <option value="Alia - The Royal Jordanian Airlines dba Royal Jordanian"></option>
                    <option value="Qatar Airways Group Q.C.S.C dba Qatar Airways"></option>

                </select>
            </div>
        </div>


        <!-- Sección hotel -->
        <div id="hotel-section" class="ocultar">

            <label for="nombre-hotel">Nombre hotel:</label>
            <input type="text" id="nombre-hotel" required>

            <label for="ciudad">Ciudad:</label>
            <input type="text" id="ciudad" required>

            <label for="precio">Precio (€):</label>
            <input type="number" id="precio" required>

            <label for="dia-entrada">Día de entrada:</label>
            <input type="date" id="dia-entrada" required>

            <label for="dia-salida">Día de salida:</label>
            <input type="date" id="dia-salida" required>

            <label for="tipo-habitacion">Tipo de habitación:</label>
            <input list="tipos" id="tipo-habitacion" name="tipo-habitacion" placeholder="--Elige--" required>
            <datalist id="tipos">
                <option value="Doble"></option>
                <option value="Doble uso individual"></option>
                <option value="Individual"></option>
                <option value="Triple"></option>
            </datalist>

        </div>

        <!-- Sección Otros servicios -->
        <div id="otros-section" class="ocultar">

            <label for="ciudad">Nombre:</label>
            <input type="text" id="ciudad" required>

            <label for="dia-salida">Fecha:</label>
            <input type="date" id="fecha" required>

            <label for="otros-info">Descripción:</label>
            <textarea id="otros-info"></textarea>

            <label for="precio">Precio (€):</label>
            <input type="number" id="precio" required>
        </div>

        <button type="submit" id="guardar">Guardar Servicios</button>
    </form>

    <script>
        // Función para mostrar y ocultar secciones principales
        function mostrarFormulario(seccion) {
            // Ocultar todas las secciones
            const secciones = ['vuelo-section', 'hotel-section', 'otros-section'];
            secciones.forEach(id => {
                document.getElementById(id).classList.add('ocultar');
            });
    
            // Mostrar la sección seleccionada
            const seleccion = document.getElementById(`${seccion}-section`);
            if (seleccion) {
                seleccion.classList.remove('ocultar');
            }
        }
    
        // Función para mostrar campos adicionales dentro de la sección de vuelos
        function mostrarFormularioVuelo(tipo) {
            // Ocultar sección de vuelo de vuelta
            const vueltaSection = document.getElementById('vuelta-section');
            if (tipo === 'ida-vuelta') {
                vueltaSection.classList.remove('ocultar');
            } else {
                vueltaSection.classList.add('ocultar');
            }
        }
    </script>
</body>

</html>